		</div>
	</div>
    <div class="padder"></div>
	
    <footer class="blog-footer">
	    <div class="footer-menu">
	      <a href="<?php echo esc_url(get_permalink( get_page_by_title( 'Retos' )  ) ); ?>">Retos</a>
	      <a href="<?php echo esc_url(get_permalink( get_page_by_title( 'Recetas' )  ) ); ?>">Recetas</a>
	      <a href="<?php echo esc_url(get_permalink( get_page_by_title( 'Tips' )  ) ); ?>">Tips</a>
	      <a href="<?php echo esc_url(get_permalink( get_page_by_title( 'Programas' )  ) ); ?>">Programas</a>
	      <label>Nutriologa Gabriela Girón - Nutgir	&copy;</label>
	      <a href="http://nuva.rocks/">Página por: NUVA.ROCKS</a>
	    </div>
    </footer>

    <?php wp_footer(); ?> 
    <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/navbar.js"></script>

  </body>
</html>