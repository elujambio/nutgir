<?php add_theme_support( 'post-thumbnails' ); ?>
<?php 
@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );
?>
